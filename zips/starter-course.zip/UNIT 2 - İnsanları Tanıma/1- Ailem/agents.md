# 1- Ailem

## Lesson
Aile üyeleri ve 有 ile sahiplik.

## Learning outcomes
- Aile üyelerini adlandırabilir.
- 我有… ile birini tanıtabilir.

## What to teach
1. 爸爸 妈妈 哥哥 姐姐
2. 我有…
3. 我没有…

## Key points and pitfalls
- 有 olumsuzu 没有; 不有 yanlıştır.
- 哥哥 (gēge) ve 姐姐 (jiějie) ikinci hece nötr tonda.

## Tutor approach
Öğrencinin gerçek ailesinden örnekler iste; tek tek kişi ekleyerek cümleyi uzat.

## Files in this topic
- `words.json` — 6 kelime.
- `text.json` — aile tanıtımı.

## Review notes
- Kitapta 弟弟 ve 妹妹 aynı sayfada; ikisi de aktif kelime yapılabilir.
