# Cevap anahtarı

1. 你好
2. 我叫阿里
3. 你叫什么名字？
