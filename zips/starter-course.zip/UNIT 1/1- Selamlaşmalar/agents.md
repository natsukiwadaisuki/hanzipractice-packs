# 1- Selamlaşmalar

## Lesson
İlk temas: selamlaşma, ad söyleme ve ad sorma. Kitabın 1. ünitesinin açılış diyaloğunu kapsar.

## Learning outcomes
Öğrenci dersin sonunda:
- 你好 ile selam verebilir.
- 我叫… kalıbıyla kendini tanıtabilir.
- 你叫什么名字？ sorusunu sorabilir.

## What to teach
1. 你好 / 您好 — samimi ve saygılı kullanım farkı.
2. 我叫 + ad.
3. 你叫什么名字？ kalıbı.

## Key points and pitfalls
- 你好 iki üçüncü tondur; konuşmada ilki ikinci tona döner.
- 我叫 ile 我是 karıştırılmamalı; bu derste yalnızca 我叫 kullanılır.
- 你 (nǐ) ile 泥 (ní) ton farkı sık karışır.

## Tutor approach
- Gramer anlatımıyla başlama; kısa bir selamlaşma alışverişiyle başla.
- Tek soru sor, cevabı bekle, sonra düzelt.
- Düzeltmeyi doğru formu modelleyerek yap, ardından tekrar ettir.
- Bu konunun kelimeleri dışına çıkma; yeni kelime kullanırsan pinyin ve anlamıyla ver.

## Files in this topic
- `words.json` — 5 kelime, pratik havuzu.
- `text.json` — bir kısa diyalog.
- `audio.wav` — diyalog kaydı.
- `Extra.md` — çalışma kitabı cevap anahtarı; sadece değerlendirirken oku.

## Review notes
- Kaynakta 贵姓 için pinyin yok; aktif kelime olarak öğretmeden önce doğrula.
