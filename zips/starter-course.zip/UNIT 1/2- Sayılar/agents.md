# 2- Sayılar

## Lesson
Bir ile on arası sayılar ve yaş sorma.

## Learning outcomes
- 1–10 arası sayıları okuyup yazabilir.
- 你几岁？ sorusunu anlayabilir.

## What to teach
1. 一二三四五
2. 六七八九十
3. 你几岁？ — 我…岁。

## Key points and pitfalls
- 二 (èr) ile 两 (liǎng) farkı: sayarken 二, miktar bildirirken 两.
- 十 (shí) ikinci ton; 四 (sì) dördüncü ton.

## Tutor approach
Sayıları sırayla söylet, sonra karışık sor. Hatalı tonu hemen değil, cümle bitince düzelt.

## Files in this topic
- `words.json` — 10 sayı.
- `text.json` — yaş diyaloğu.
