![Starter course cover](cover.png)

# Selamlaşma ve Aile — Başlangıç Paketi

**Hanzi Practice'ten ilk adım.** Sıfırdan başlayanlar için iki ünite, üç konu ve
21 temel kelime. Hepsi yazma pratiği, telaffuz ve mini derslerle birlikte geliyor.

> Made with love by HanziPractice team <3

## Bu pakette ne var?

| Ünite | Konu | İçerik |
|---|---|---|
| UNIT 1 | 1- Selamlaşmalar | Selam, ad söyleme, ad sorma — 5 kelime |
| UNIT 1 | 2- Sayılar | 1–10 arası sayılar — 10 kelime |
| UNIT 2 | 1- Ailem | Aile üyeleri ve 有 — 6 kelime |

## Nasıl çalışılır?

1. **Konuyu aç**, önce *Texts / Reading* sekmesindeki diyaloğu dinle.
2. **Vocabulary** sekmesinde kelimeleri gözden geçir.
3. **Start Topic Test** ile yazma pratiğine başla. İlk 4 tekrar izli, sonraki 4 tekrar ezberdir.
4. Takıldığında **Skip** kullan: kelimeyi göstermeden yalnızca o tekrarı geçer.
5. **AI Tutor**'a "Bu ünitedeki selamlaşmalarla benimle konuş" diyebilirsin.

## Öğrenme çıktıları

- 你好 ve 您好 ile selam verebilir.
- 我叫… kalıbıyla kendini tanıtabilir.
- 你叫什么名字？ sorusunu sorabilir ve cevaplayabilir.
- 1–10 arası sayıları okuyup yazabilir.
- 我有… / 我没有… ile ailesinden bahsedebilir.

## İpuçları

- **Tonlar anlamı değiştirir.** 你 (nǐ) ve 泥 (ní) aynı hece, farklı ton.
- **İzlerken yavaş ol.** Ghost karakterin üzerinden geç; hız sonra gelir.
- **Skip'i utanmadan kullan.** Bir kez görmek, on kez yanlış ezberlemekten iyidir.
- **Her gün 10 dakika**, haftada bir 70 dakikadan iyidir.

---

Sorun mu var? Paketi yeniden içe aktarabilirsin; ilerlemen ayrı saklanır.
