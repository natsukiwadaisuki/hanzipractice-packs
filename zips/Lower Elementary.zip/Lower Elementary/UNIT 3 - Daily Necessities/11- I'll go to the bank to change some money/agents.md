# 11- I'll go to the bank to change some money

## Lesson
Lesson 11 (printed pp. 99–107). Meeting an old friend: greetings, health, where you live
now, phone numbers — plus serial-verb sentences (去/来/回 + purpose) and numbers above 100
with currency names.

## Learning outcomes
By the end the student can:
- Open and close a conversation: 好久不见！你好吗？ — 很好，谢谢。再见！
- Ask after family: 你爸爸、妈妈身体好吗？ — 他们都很好.
- Say where they are going and why: 我去银行换钱 / 下午去超市买点儿东西.
- Give an address and a phone number: 我住12号楼，301房间 / 82306154.
- Read numbers above 100: 二百, 一千二, 一万三千六百九十四.

## What to teach (priority order)
1. 去/来/回 + place + verb phrase — the serial verb pattern, the grammar core of the lesson:
   我去银行换钱 (one subject, two verbs, second = purpose).
2. Number system above 100: 百 千 万, and the "round" short forms 两百 / 两千 / 一万二.
3. Currency names: 美元 欧元 日元 人民币.
4. Small-talk set: 你好吗 / 你怎么样 / 学习忙不忙 / 身体好吗.
5. 还 "still" and 空儿 "free time" in 有空儿来我宿舍玩儿.

## Key points and pitfalls
- Serial verbs share one subject and are not joined by 和: 我去银行换钱 ✓,
  我去银行和换钱 ✗.
- No 去 twice: 我去银行去换钱 ✗.
- 来 vs 去 depends on the listener's position: 有空儿来我宿舍玩儿 (toward the listener).
- 一百零一 has 零 where a place value is skipped: 101 一百零一, 110 一百一十, 111 一百一十一.
- Above 100 counting uses 二 (二百), but before a measure word it is 两 (两百 / 两百块).
- 万 = 10,000, not 100,000 — English speakers mis-group large numbers here constantly.
- 好久不见 is a fixed greeting; do not analyse it word by word with beginners.
- Phone numbers are read digit by digit, and 1 is always yāo (not yī) in phone/room numbers
  in real speech; the book's audio uses the digit reading — mention it.
- 东西 dōngxi has a neutral second syllable and means "thing", not "direction".
- 还 hái (still) is not huán (to return something).

## Tutor approach
- Rehearse the greeting as a two-minute street encounter, end to end, then repeat faster.
- Build serial-verb sentences by chaining the student's real errands: 我去超市买东西.
- Practise phone numbers and room numbers — they are the most satisfying "I can use this"
  moment of the lesson.
- Drill big numbers with banknote serial numbers, then the student's own country's currency.
- Stay inside this topic's 29 words plus Lessons 1–10 vocabulary.

## Files in this topic
- `words.json` — 29 words: the 20 numbered entries plus the unnumbered component and
  companion words printed inside the same tables (好久, 久, 见, 人民, 币 …).
- `text.json` — the reunion dialogue and the short errands text (二).
- No audio shipped; the app falls back to TTS.

## Review notes
- Transcripts are English translations written for this package. Gavin = 加文, Martin = 马丁.
- This topic has 29 words (the largest in the book). If the practice queue feels long, split
  after 再见: greetings/errands first, numbers and currencies second.
- 好久不见 is stored with sandhi applied (bú jiàn); the book prints the phrase without tone
  marks on the function words in the vocabulary table.
