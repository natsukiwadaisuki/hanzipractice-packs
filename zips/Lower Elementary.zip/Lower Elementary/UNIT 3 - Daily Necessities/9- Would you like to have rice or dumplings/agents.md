# 9- Would you like to have rice or dumplings

## Lesson
Lesson 9 (printed pp. 79–89), opening Unit 3. Food and drink, offering and refusing, and
the two big question types of the unit: A还是B？ (choice) and X不/没X？ (yes-no by
repetition). The setting is a host offering tea and a restaurant ordering.

## Learning outcomes
By the end the student can:
- Offer something: 请进！请坐！请喝茶！
- Ask a choice question: 茶还是咖啡？ — 我喝茶.
- Ask an A-not-A question: 你喝不喝啤酒？ — 不喝，我喝茶.
- Order in a restaurant: 几位？吃点儿什么？有没有面条？
- Make a suggestion and agree: 吃饺子吧。 — 行。

## What to teach (priority order)
1. A 还是 B for questions only; 对 alternatives in statements use 不是A就是B (not taught)
   — keep 还是 strictly interrogative here.
2. A-not-A patterns: V不V (吃不吃), V了没有, Adj不Adj (难不难), 是不是, 有没有.
3. 有 question form is 有没有, never 有不有.
4. 吧 for a suggestion: 吃饺子吧. 行 / 不行 to accept or refuse.
5. Food vocabulary as a block: 米饭 饺子 包子 面条 面包 茶 咖啡 啤酒.
6. 请 + verb as the offering formula: 请进 / 请坐 / 请喝茶.

## Key points and pitfalls
- A-not-A questions take no 吗: 你喝不喝啤酒？ ✓ / 你喝不喝啤酒吗？ ✗.
- 有没有 ✓, 有不有 ✗. This is the one irregular pattern.
- In Adj不Adj questions, drop degree adverbs: 汉语难不难 ✓ / 汉语很难不难 ✗.
- Noun predicates need 是不是: 今天是不是星期三 ✓ / 今天星期三不星期三 ✗.
- With an object, both 你吃不吃饭 and 你吃饭不吃 are possible; teach the first as default.
- 咱们 includes the listener ("we two"), 我们 can exclude them. In 咱们吃米饭还是饺子？ the
  speaker is deciding together with the listener.
- 还是 is used only in questions; English "or" in statements is not 还是.
- 点儿 is erhua: diǎnr, one syllable. 吃点儿什么 is the soft, polite way to offer.
- 啤酒 is beer; 酒 alone means alcohol in general, so 啤酒 is the word students need.
- 饺子 jiǎozi, 包子 bāozi, 面条 miàntiáor — the final syllables are light; do not stress them.

## Tutor approach
- Run it as a real meal: offer tea or coffee, have the student answer with 还是-form choices.
- Convert every statement the student makes into an A-not-A question and back.
- Role-play the restaurant with the menu from the book's comprehensive exercise (牛肉 猪肉
  鸡肉 蔬菜 / 米饭 面条 饺子 包子 / 啤酒 可乐 茶).
- When the student says 有不有 or adds 吗 to an A-not-A question, model the right form once
  and move on — repetition fixes it faster than explanation.
- Stay inside this topic's 21 words plus Lessons 1–8 vocabulary.

## Files in this topic
- `words.json` — 21 words: 19 numbered entries plus 不行 and 酒 printed under the same
  numbers in the book's tables.
- `text.json` — the host/guest dialogue and the restaurant dialogue (二).
- No audio shipped; the app falls back to TTS.

## Review notes
- Transcripts are English translations written for this package.
- The book lists the word as "(一)点儿 (yì)diǎnr"; stored as 点儿 / diǎnr so the handwriting
  practice is not polluted by the parentheses. Teach 吃点儿 / 喝点儿 as the live chunk.
- 还是 is stored háishi as printed; dictionaries also write háishì.
