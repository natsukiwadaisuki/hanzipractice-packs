# 10- How much does half a kilo of apples cost

## Lesson
Lesson 10 (printed pp. 90–99). Buying fruit: asking prices, reading sums of money in
块/毛/分, bargaining politely, and paying with change. Two texts only — a short price
monologue and one long haggling dialogue.

## Learning outcomes
By the end the student can:
- Ask 苹果多少钱一斤？ and answer 三块 / 三块五.
- Read money aloud: 两块五, 一块三毛九, 十块零三毛, 八块五.
- Bargain: 太贵了，便宜一点儿吧。四块一斤，怎么样？
- Add to an order and total it: 还要一斤香蕉。一共多少钱？
- Hand over money and take change: 给你钱。 — 这是十五块，找您三块.

## What to teach (priority order)
1. 多少钱 and the price sentence: 苹果三块一斤 (money before or after the unit both work).
2. Money reading: 块 (yuan) → 毛 (jiao) → 分 (fen), largest first, trailing units dropped:
   1.30 = 一块三, 1.39 = 一块三毛九.
3. 太 … 了 as a frame: 太贵了 / 太好了.
4. 便宜一点儿吧 and 怎么样 as the bargaining pair.
5. 还 / 别的 / 一共 / 找 in the checkout sequence.

## Key points and pitfalls
- Chinese reads money without the decimal point: 2.05 is 两块零五(分), not 两块零点五.
- 毛 is spoken, 角 is the written/formal word for the same unit; 分 is the smallest unit and
  is rarely heard in prices today but is still tested in the book.
- 块五 means "one yuan fifty" only when the yuan figure is in context: 八块五 = 8.50. A bare
  两块五 is 2.50, never "half a yuan".
- 斤 is half a kilogram, not a kilo. Western learners always assume kilo — say it out loud.
- 便宜 piányi has a neutral second syllable, and it means cheap (positive in Chinese
  shopping talk), not "shabby".
- 太贵了 needs 了 — 太贵 ✗ in this use.
- 找 zhǎo here means "give change", the same character as 找 in 找人 (look for). Different
  meaning, same word form; keep them apart in drills.
- 还 is hái ("still, also more"), not huán ("return") which comes later.

## Tutor approach
- Set a market stall with real prices on paper; the student must buy two things and total it.
- Drill money reading as fast call-and-response: say a number, student says the price.
- Teach the bargaining script as one memorised chunk: 太贵了，便宜一点儿吧。… 怎么样？
- Correct decimal-style readings (两块零点五) immediately by replaying the natural form.
- Stay inside this topic's 20 words plus Lessons 1–9 vocabulary.

## Files in this topic
- `words.json` — 20 words: 16 numbered entries, with 块/元 and 毛/角 split into separate
  characters so each can be practised.
- `text.json` — the price monologue (一) and the haggling dialogue (二).
- No audio shipped; the app falls back to TTS.

## Review notes
- Transcripts are English translations written for this package.
- The book's entry "太……了 tài……le" is stored as 太 with the frame noted in the meaning.
- 分 appears here as a money unit and in Lesson 6 as "minute" — same character, two meanings.
