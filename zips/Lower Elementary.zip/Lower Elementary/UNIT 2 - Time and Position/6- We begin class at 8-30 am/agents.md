# 6- We begin class at 8:30 am

## Lesson
Lesson 6 (printed pp. 52–60). Telling time and describing a daily/weekly schedule: what
time you get up, when class starts and finishes, which day you have nothing. The largest
vocabulary set of the unit (25 words), most of them time nouns.

## Learning outcomes
By the end the student can:
- Ask the time: 现在几点？ / 请问，现在几点？
- Say times: 八点, 八点零五分, 八点十分, 八点一刻, 八点半, 差五分九点.
- Say when they get up, sleep, start and finish class, with 早上/上午/中午/下午/晚上.
- Ask 几点…？ and 什么时候…？ and answer with a time phrase before the verb.
- Say which day they have no class: 我星期五没有课.

## What to teach (priority order)
1. Hour + 点 + minutes: 八点十分; 零 for the first ten minutes (八点零五分).
2. 刻 (15) and 半 (30) as the natural spoken forms: 七点一刻, 八点半.
3. 差 + minutes + target time for "to": 差十分四点 = 3:50.
4. Time phrase goes before the verb: 我们上午八点半上课 — never at the end.
5. Parts of the day: 早上 / 上午 / 中午 / 下午 / 晚上, and 时候 in 什么时候.

## Key points and pitfalls
- Time is an adverbial in Chinese: subject + time + verb. "I get up at seven" is 我七点起床,
  not 我起床七点.
- 半 comes after the hour: 八点半 (never 半八点), and 半 cannot combine with 分: 八点半 ✓,
  八点半十五分 ✗.
- 点 is a measure word here: 三点, not 三个点.
- 刻 is the spoken quarter; in this book 三点四十五 is avoided in favour of 差一刻四点.
- 零 in times is read, not skipped: 八点零五分 = 8:05. Dropping it gives 八点五分, which is
  a different, less careful form.
- 不用谢 is the answer to 谢谢 here; 不谢 is the shorter form from Lesson 5.
- 上课 means both "class starts" and "I attend class" — the time phrase disambiguates.
- 时候 only appears in 什么时候 (when); it is not a countable "time".
- Tone trap: 上 shàng vs 下 xià in 上午/下午, 上课/下课 — a matched pair, drill them together.

## Tutor approach
- Open with a clock: ask the time, have the student answer, then swap roles.
- Have the student describe their real day: 我早上七点起床, 我们上午八点半上课.
- Always echo a mis-ordered sentence correctly and ask for a repeat, since the word-order
  error is the core learning point of this lesson.
- Drill 差-forms as a fast back-and-forth; they feel foreign and need repetition.
- Stay inside this topic's 25 words plus earlier vocabulary.

## Files in this topic
- `words.json` — 25 words: 20 numbered entries plus the 5 unnumbered sub-entries printed in
  the same tables (用, 床, 睡, 上, 下).
- `text.json` — the street-time dialogue and the schedule dialogue (二).
- No audio shipped; the app falls back to TTS.

## Review notes
- Transcripts are English translations written for this package.
- The folder name uses "8-30 am" because ":" is not allowed in folder names; the book title
  is "We begin class at 8:30 am".
