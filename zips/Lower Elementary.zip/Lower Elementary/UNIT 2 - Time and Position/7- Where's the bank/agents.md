# 7- Where's the bank

## Lesson
Lesson 7 (printed pp. 61–68). Asking for and giving locations. The student learns the six
direction words with 边, the verb 在, and how to point at buildings: 东边的那座楼是银行.

## Learning outcomes
By the end the student can:
- Ask 银行在哪儿？ and answer 银行在东边.
- Say something is next to something else: 银行在书店东边.
- Point with 这 / 那 and count buildings: 哪座楼是银行？那座楼是4号楼.
- Name the places of a campus: 银行, 书店, 学校, 宿舍.
- Respond to thanks with 不客气.

## What to teach (priority order)
1. 在 + place/direction as the predicate: 银行在东边. There is no "am/is/are" separate verb.
2. The six directions + 边: 东边 西边 南边 北边 前边 后边.
3. Reference place before direction, no 的: 书店东边 (NOT 书店的东边).
4. 哪儿 and 哪儿 questions, plus 请问 as the polite opener.
5. 那 vs 这, and the measure word 座 for large buildings.

## Key points and pitfalls
- 在 is a verb, not a preposition: 我在宿舍 = "I am in the dorm". Negate with 不在.
- Direction words used as the head take no 的: 书店东边 ✓, 书店的东边 ✗.
- When a direction word modifies a noun it may take 的: 东边(的)那座楼 — both are fine.
- Chinese map convention is north-up like English, but 前/后 follow the face of the
  building, not the viewer; keep it simple and use the book's campus picture.
- 哪儿 is nǎr with the erhua; 哪儿 is spoken, 哪里 is the non-erhua variant (not in this lesson).
- 号 here is the number of a building (1号楼); it is the same character as the 号 for a date
  in Lesson 5 but a different meaning and measure-word use.
- 楼 is "building" and also "floor" — 二楼 is "second floor", which comes later.
- 不客气 is bú kèqi (不 becomes second tone before 客).

## Tutor approach
- Draw or imagine a simple campus map and ask 银行在哪儿？; then have the student place
  things: 学校在你前边.
- Drill the six directions as pairs (东边/西边, 南边/北边, 前边/后边).
- Use the student's real city: 银行在你家东边吗？
- Correct 书店的东边 immediately — this is the lesson's grammar trap.
- Stay inside this topic's 27 words plus earlier vocabulary.

## Files in this topic
- `words.json` — 27 words: 16 numbered entries plus the unnumbered direction and
  component characters printed in the same tables (东, 边, 西, 店, 客气, 北, 南, 前, 后).
- `text.json` — the street dialogue and the campus description (二).
- No audio shipped; the app falls back to TTS.

## Review notes
- Transcripts are English translations written for this package.
- 号 appears in both Lesson 5 (date) and Lesson 7 (building number). Both are kept in
  their own topic; the tutor should point out the difference if the student notices.
