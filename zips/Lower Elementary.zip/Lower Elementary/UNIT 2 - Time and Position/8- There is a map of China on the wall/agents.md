# 8- There is a map of China on the wall

## Lesson
Lesson 8 (printed pp. 69–78), the last lesson of Unit 2. Existence with 有 after a place
phrase, furniture vocabulary, and the second set of position words (里/外/上/下/左/右/旁/中间).
The student describes a room.

## Learning outcomes
By the end the student can:
- Say what is where: 房间里有一张床 / 墙上有一张中国地图.
- Negate existence: 桌子上没有书.
- Name the furniture of a room and count it with the right measure words.
- Place objects: 我的床在左边, 我们的桌子在床旁边, 词典在中间.
- Ask where something is with 呢: 大卫的书呢？

## What to teach (priority order)
1. Place phrase + 有 + thing: 桌子上有一本书 — this is "there is/are", not 是.
2. Position words of this lesson: 里 外 上 下 左 右 旁 中间 (+ 边 forms).
3. Furniture set with measure words: 一张床, 一张桌子, 一把椅子, 一个书架, 一个柜子.
4. 呢 as a short "and what about…?" question.
5. 上边/下边 for shelves (upper/lower part) vs 上/下 after a noun (on/under).

## Key points and pitfalls
- Never put 在 in front of a locality phrase that is the subject: 房间里有一张桌子 ✓,
  在房间里有一张桌子 ✗. This is the main grammar trap of the lesson.
- Negative existence forbids a number + measure word on the object: 桌子上没有书 ✓,
  桌子上没有一本书 ✗.
- 有 (there is) vs 是 (it is): 墙上有一张地图 (it exists there) vs 那是一张地图 (identifying it).
- After an ordinary place noun use 里, but never after a country or city name: 房间里 ✓,
  中国里 ✗, 北京里 ✗.
- After a noun as the head, the plain 里/上/下 are more natural than 里边/上边: 房间里, 桌子上.
- 上 shàng (on) and 上 shàng (start class, Lesson 6) are the same character with different
  senses; 下 likewise. Point this out only if the student asks.
- 桌子, 椅子, 柜子, 本子 all end in a neutral 子 — never stress it.
- 呢 is not "ne" as in English: it is a light particle that turns a noun into "what about X?"

## Tutor approach
- Describe the student's own room first, one item at a time, then have them describe the
  book's room back to you.
- Use a real shelf or desk to drill 上边 / 下边 / 中间 physically.
- When the student says 在房间里…, repeat the sentence without 在 and have them repeat it.
- Practise 呢 as a chain: 我的书呢？在你的桌子上。
- Stay inside this topic's 23 words plus Lesson 1–7 vocabulary.

## Files in this topic
- `words.json` — 23 words: 15 numbered entries plus the unnumbered position and component
  characters printed in the same tables (里边, 外, 外边, 上边, 左, 右, 旁, 下).
- `text.json` — the two room descriptions (一)(二).
- No audio shipped; the app falls back to TTS.

## Review notes
- Transcripts are English translations written for this package.
- 上/下/里/外 appear both here and, for 上/下 as verbs, in Lesson 6; the tutor should keep the
  two senses apart when correcting.
