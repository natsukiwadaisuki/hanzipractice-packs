# 5- My birthday is on 9th, May

## Lesson
Lesson 5 (printed pp. 43–51), the first lesson of Unit 2. The student gives and asks
dates, wishes someone a happy birthday, gives a present, and uses the adjective-predicate
sentence (我很高兴) instead of 是 + adjective.

## Learning outcomes
By the end the student can:
- Ask and answer the date: 今天几月几号？ — 五月九号.
- Add the weekday: 五月九号星期二.
- Say and ask about birthdays: 我的生日是十月十二号 / 你的生日是几月几号？
- Congratulate: 祝你生日快乐, and respond 谢谢 / 不谢.
- Use 很 + adjective without 是: 我很高兴 / 汉语不难.

## What to teach (priority order)
1. Date order: month → day → weekday (五月九号星期二). Never day first.
2. 几月几号 as the fixed question for a date; 号 in speech, 日 in writing.
3. Birthday sentence: 我的生日是 + date.
4. Adjective predicate: 我很高兴, 汉语不难 — no 是.
5. 祝 + person + 生日快乐; 谢谢 / 不谢 as a pair.

## Key points and pitfalls
- There is no 是 between subject and adjective: 我很高兴 ✓ / 我是很高兴 ✗.
- 很 in 我很高兴 is not "very" in the strong sense — it is a weak, unstressed linker. Without
  it the sentence sounds comparative ("I'm happy, [you're not]").
- Dates and times go from large to small: 十月十二号, not 十二号十月.
- 号 is spoken, 日 is written; both mean the day of the month.
- 二 in dates is èr (十二月 èr, not liǎng), unlike counting with measure words.
- The negative of a date sentence uses 不是: 今天不是六号.
- Months and weekdays are built, not memorised: 一月…十二月, 星期一…星期日/天. They are not
  separate word entries in this topic.
- 星期 is xīngqī; 星期日 and 星期天 are both Sunday.

## Tutor approach
- Start with today's real date: 今天几月几号星期几？
- Then the student's own birthday, then the book's characters' birthdays.
- Drill 是 vs no-是 with two frames: 我的生日是… (needs 是) vs 我很高兴 (no 是).
- Keep 很 light when modelling — do not stress it.
- Stay inside this topic's 18 words plus earlier vocabulary.

## Files in this topic
- `words.json` — 18 words, including 号 and 日 split into two entries.
- `text.json` — the birthday dialogue and Annie's diary (二).
- No audio shipped; the app falls back to TTS.

## Review notes
- Transcripts are English translations written for this package.
- The book lists 号/日 as one entry with the reading hào/rì; split here into 号 and 日 so
  each character can be practised.
- The diary heading "五月九号  星期二" is kept inside the text body.
