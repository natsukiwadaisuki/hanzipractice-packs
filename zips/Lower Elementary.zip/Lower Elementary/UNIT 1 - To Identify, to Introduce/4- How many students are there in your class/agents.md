# 4- How many students are there in your class

## Lesson
Lesson 4 (printed pp. 33–42). The student counts up to 99, asks about numbers with 几 and
多少, and talks about a class: students, nationalities, what they study, and whether it is
difficult.

## Learning outcomes
By the end the student can:
- Count and read the numbers 1–99 in Chinese.
- Ask 你们班有多少学生？ and answer with a number + measure word.
- Choose 几 for numbers under ten and 多少 for larger numbers.
- Say what someone studies: 我学习汉语 / 英语.
- Use 都 for "all": 我们都学习汉语, and negate it: 不都是.

## What to teach (priority order)
1. Numbers 1–99: 十 as ten, 二十 = 20, 二十二 = 22, 九十九 = 99.
2. 多少 + (optional measure word) + noun: 有多少学生 / 有多少个学生.
3. 几 + mandatory measure word: 有几个学生, 你家有几口人.
4. 学习 + language: 学习汉语 / 学习英语.
5. 都 before the verb: 我们都学习汉语; 不都是 = "not all".

## Key points and pitfalls
- 二 is used in counting (二十二), 两 before a measure word (两个学生). Never 二十两.
- 十 is not "one ten": 15 is 十五, not 一十五 (in this range).
- 几 needs a measure word; 多少 does not. 你们班有多少学生 ✓ / 你们班有几学生 ✗.
- 都 goes before the verb and after the subject: 我们都学习汉语, never 都我们学习.
- 不都 vs 都不: 不都是 = "not all are"; 都不是 = "none are". Big meaning difference.
- 汉语 is Hànyǔ (capital H), 英语 is Yīngyǔ — language names from country names.
- 哪 is nǎ (něi in fast speech); 那 (nà, "that") is a different character — do not mix.
- 朋友 has a neutral second syllable: péngyou, not péngyǒu.

## Tutor approach
- Drill numbers as a game: read a phone number, count objects, then 22 / 15 / 7 from the text.
- Ask the student about their own class size and subjects — real numbers, real answers.
- Contrast 几 and 多少 with two questions the student answers about their own class.
- For 都, use a group statement about the class, then ask a yes/no question that needs 不都是.
- Stay inside this topic's 21 words plus Lesson 1–3 vocabulary.

## Files in this topic
- `words.json` — 21 words: 16 numbered entries plus 5 unnumbered sub-entries from the same
  tables (学, 语, 英语, 男, 女).
- `text.json` — two texts and the dormitory dialogue (三) with its stage direction.
- No audio shipped; the app falls back to TTS.

## Review notes
- Transcripts are English translations written for this package.
- The book writes class sizes with Arabic numerals (22, 15, 7); kept verbatim in the text.
- 哪 is stored as nǎ; the book also prints the reading něi.
