# 2- This is Annie's map

## Lesson
Lesson 2 (printed pp. 12–21). The student identifies objects, asks whose they are with
的, says what they have with 有, and counts things with measure words. Three short texts
plus a strong measure-word section.

## Learning outcomes
By the end the student can:
- Point at something: 这是你的书吗？ — 是 / 不是，这是山本的词典.
- Express possession with owner + 的 + noun.
- Say what they have and don't have: 我有词典 / 我没有地图.
- Use 本, 张, 支, 个 with the right nouns.
- Use 两 instead of 二 before a measure word.

## What to teach (priority order)
1. 的 as the possessive link: 我的 / 你的 / 山本的 / 安妮的.
2. 有-sentence: 我有…, and its negative 没有 (never 不有).
3. Measure words 本 (books), 张 (flat things), 支 (pens), 个 (default).
4. 两 + measure word vs 二 as a number.
5. 这 (this) as the pointer in 这是…; contrast 那不是… only passively.

## Key points and pitfalls
- Negative of 有 is 没有, not 不有. This is the single most common beginner error.
- With a negative 有-sentence the object takes no number + measure word:
  我没有词典 ✓ / 我没有一本词典 ✗.
- 两, not 二, before a measure word: 两个本子, 两张地图.
- 的 is often dropped in close relationships in real Chinese, but this lesson always uses
  it — keep it while the student is learning.
- 一 changes tone: yì before 1st/2nd/3rd tone (一张 yì zhāng, 一支 yì zhī), yí before a 4th
  tone (一个 yí gè). Drill by ear.
- 本 is both a noun ("root/volume") and the measure word for books; 本子 is "notebook".
- 笔 is a general "pen/pencil"; 一支笔 is the counted form.

## Tutor approach
- Start by pointing at real objects on the desk: 这是你的书吗？ Make it physical.
- Do the 有-drill as a survey: 你有词典吗？ 我没有词典.
- Correct 不有 immediately and firmly — model 没有 and have the student repeat.
- When the student forgets a measure word, accept the sentence, then replay it with the
  measure word and ask them to repeat.
- Use only this topic's 14 words plus Lesson 1's pronouns.

## Files in this topic
- `words.json` — 14 words: 7 objects, 有 / 没有, and 5 measure/number words.
- `text.json` — the three lesson texts (一)(二)(三) with English translations.
- No audio shipped; the app falls back to TTS.

## Review notes
- Transcripts are English translations written for this package.
- The book introduces 那 (that) later; do not teach it here even if the student asks.
