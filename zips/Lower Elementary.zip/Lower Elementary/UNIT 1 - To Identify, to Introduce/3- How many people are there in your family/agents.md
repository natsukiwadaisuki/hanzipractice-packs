# 3- How many people are there in your family

## Lesson
Lesson 3 (printed pp. 22–32). The student talks about family, asks who someone is, what
something is, and how many there are — all with question words used in place (no
reordering). Vocabulary is mostly family nouns plus the three question words.

## Learning outcomes
By the end the student can:
- Ask and answer 你家有几口人？ — 我家有四口人.
- Ask 这是什么？ / 他是谁？ and answer.
- Ask about someone's job: 你爸爸做什么工作？ — 我爸爸是老师.
- List family members with 和, and negate a list with 也没有.
- Count people with 口 and things with 个.

## What to teach (priority order)
1. 几 + measure word for small numbers: 几口人, 几个本子.
2. Question words in place: 谁 / 什么 / 几 keep the statement's word order.
3. 做工作 pattern: 做什么工作？ and the answer 我爸爸是老师 / 妈妈不工作.
4. Family nouns in pairs: 爸爸/妈妈, 哥哥/弟弟, 姐姐/妹妹.
5. 和 for "and" between nouns; 也 for "also"; 也没有 for "neither".

## Key points and pitfalls
- 几 asks for a small number (usually under ten); 多少 comes in Lesson 4 for larger ones.
- 口 is the measure word for people counted as family members, not a general "person"
  counter: 四口人 ✓, but 四个学生 for students.
- Family nouns are reduplicated with a neutral second syllable: bàba, māma, gēge, jiějie,
  mèimei, dìdi. Stressing both syllables sounds foreign.
- 谁 is shéi in speech, shuí in careful reading; the book gives both.
- 大夫 (dàifu) is the spoken word for doctor; 医生 is the written/formal one.
- 工作 is both noun and verb: 我妈妈不工作 (verb), 你做什么工作 (noun).
- 他 / 她 in "他是谁" — the answer fixes gender: 她是我妈妈.

## Tutor approach
- Ask about the student's real family first, then the book's families.
- Use a photo or a drawing as the prompt for 这是谁？/ 你家有几口人？
- Drill question words by substitution: same sentence, swap 谁 → 什么 → 几.
- Correct the neutral tone in 爸爸/妈妈 by echoing the word, not by explaining tones.
- Stay inside this topic's 17 words plus Lesson 1–2 vocabulary.

## Files in this topic
- `words.json` — 17 words: 7 question/grammar words, 8 family nouns, 全.
- `text.json` — the two dialogues and Lin Yue's letter (三).
- No audio shipped; the app falls back to TTS.

## Review notes
- Transcripts are English translations written for this package.
- The letter in text 3 is dated 2008.6.10 in the book; kept verbatim.
- 谁 is stored as shéi; the book also prints the reading shuí.
