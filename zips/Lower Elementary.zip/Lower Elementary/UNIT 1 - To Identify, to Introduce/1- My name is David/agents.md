# 1- My name is David

## Lesson
Opening lesson of the book (Lesson 1, printed pp. 2–11). Three short texts introduce the
characters, the 是-sentence, the question particle 吗 and the adverb 也. The student
learns to say who they are, ask someone's nationality and answer yes/no.

## Learning outcomes
By the end the student can:
- Greet someone with 你好 and reply to a greeting.
- Introduce themselves with 我叫… and state a nationality with 我是…人.
- Ask 你是…吗？ and answer with 是 / 不是.
- Use 也 to say "too" (她也是加拿大人).
- Use the plural forms 我们 / 你们 / 他们 / 她们.

## What to teach (priority order)
1. 我叫 + name — the single most useful pattern in the lesson.
2. 是-sentence: 我是法国人 / 我不是中国人. Positive, then negative with 不.
3. 吗-question: 你是法国人吗？ — answer with the same verb, not with 对/不对.
4. 也 before the verb: 我也是学生 / 她也是加拿大人.
5. 您 (polite you) vs 你, and 老师 as a form of address (老师，您好).
6. Plural 们: 我们 你们 他们 她们.

## Key points and pitfalls
- Answering 吗-questions: say 是 / 不是, not 对 / 不对. 对 is not taught here.
- 不 is bù (4th tone) alone, but bú before a 4th tone: 不是 bú shì, 不叫 bú jiào. This is the
  lesson's phonetics point — drill it as sound, not as a rule.
- 他 / 她 / 它 are all tā. Written form carries the gender; speech does not.
- 您 is polite but 您们 is not used in this book — address a group with 你们.
- 是 is never used with 我叫: 我是大卫 is wrong for introducing yourself in this lesson.
- 老师 is both "teacher" and a title: say 丁老师, never 老师丁.
- 人 is the neutral-tone-ish suffix in 日本人 / 法国人 / 中国人 — do not stress it.

## Tutor approach
- Open with a two-line greeting exchange; get the student saying 我叫… before any grammar.
- One question per turn, wait for the answer, then correct by modelling the right sentence
  and asking for a repeat.
- Keep explanations to one or two lines. Use only this topic's 23 words; gloss anything
  else with pinyin + meaning.
- Drill the 不 tone sandhi by ear (不是, 不叫, 不去) rather than by explanation.
- Role-play the three texts: student is David, then Martin, then the teacher.

## Files in this topic
- `words.json` — 23 words: the 19 numbered new words of the lesson plus the four derived
  plural pronouns printed in the same table (我们 你们 他们 她们).
- `text.json` — the three lesson texts (一)(二)(三), each with an English translation.
- No audio shipped: the book's CD was not available, so the app's TTS is used.

## Review notes
- Transcripts are English translations written for this package; the book prints pinyin
  above each line instead of a translation.
- 学生 is transcribed xuésheng (neutral second syllable) as printed in the book; some
  dictionaries give xuéshēng.
