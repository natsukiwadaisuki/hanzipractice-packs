# Lower Elementary 1 (UNIT 1-11 CIE Port)

![Cover](cover.png)

Lower-elementary Chinese course, ported from the CIE textbook. The course covers
Units 1–3 and lessons 1 through 11 of the original book, retitled in the new
format.

## What's inside

- **UNIT 1 – To Identify, to Introduce** (Lessons 1–4): self-introduction,
  basic 是-sentences, the question particle 吗, and people around you.
- **UNIT 2 – Time and Position** (Lessons 5–8): birthdays, the clock, asking for
  directions, and describing objects in the room.
- **UNIT 3 – Daily Necessities** (Lessons 9–11): food choices, money and the bank.

Each lesson ships with its own `words.json` vocabulary list, `text.json` readings,
and an `agents.md` teaching brief that the AI tutor reads first.

## How to use

Import this zip in the HanziPractice app. Practice each lesson's words, read the
readings, and chat with the tutor using only the vocabulary the lesson teaches.
No audio is bundled; pronunciation falls back to the app's built-in TTS.
